<?php

namespace App\Services;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

/**
 * Class ProfileService.
 */
class ProfileService
{
    /**
     *Update user's profile.
     *
     * @param Object $request
     * @return array
     */
    public static function updateProfile($request)
    {
        $data = $request->all();
        $user = $request->user();

        $user->fill($request->validated());
        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }
        if($request->profile_picture){
            $profile_path = self::storeProfilePicture($user, $data);
            $user->profile_picture = $profile_path['profile_picture'];
        }
        $user->save();
        return $user;
    }

    /**
     * Store a user's profile picture.
     *
     * @param User $user
     * @param array $data
     * @return array
     */
    public static function storeProfilePicture(User $user, $data)
    {
        $file = ($user->profile_picture) ?? "";

        if (!empty($data['profile_picture'][0])) {
            $filename = $data['profile_picture'][0];

            // Generate a unique filename based on timestamp and user ID
            $newFileName = Carbon::now()->timestamp . '.' . $user->id . '.' . $filename->getClientOriginalExtension();

            // Define the storage path
            $filePath =  'profile-pictures/' .$user->name . '/' . $newFileName;

            // Store the user's profile picture using Laravel Storage facade
            Storage::disk('public')->put($filePath, file_get_contents($filename));

            $file = $filePath;
        }

        return [
            'profile_picture' => $file
        ];
    }


    /**
     * Delete a user's profile picture.
     * @return bool
     */
    public static function deleteProfilePicture(Request $request)
    {
        $user = $request->user();
        $filePath = $user->profile_picture;

        // Check if the file exists
        if (Storage::disk('public')->exists($filePath)) {
            // Delete the file
            Storage::disk('public')->delete($filePath);

            // Update the user's profile_picture field to null or remove it as needed
            $user->profile_picture = null;
            $user->save();

            return true;
        }
        return false;
    }
}
