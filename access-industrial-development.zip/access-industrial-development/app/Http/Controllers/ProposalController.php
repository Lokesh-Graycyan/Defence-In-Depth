<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Inertia\Response;
use Inertia\Inertia;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;

class ProposalController extends Controller
{
    /**
     * Display the Proposal List.
     */
    public function index(): Response
    {
        
        return Inertia::render('Proposal/Index', [
            
        ]);
    }

    /**
     * Display the Proposal create page.
     */
    public function create(): Response
    {
        return Inertia::render('Proposal/Create');
    }
}
