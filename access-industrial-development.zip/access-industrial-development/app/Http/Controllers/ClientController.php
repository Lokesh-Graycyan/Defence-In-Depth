<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Client;
use Inertia\Response;
use Inertia\Inertia;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;

class ClientController extends Controller
{
    /**
     * Display the client List.
     */
    public function index(): Response
    {
        // Fetch client data
        $clients = Client::orderBy('id', 'DESC')->paginate(10);
    
        return Inertia::render('Client/Index', [
            'clients' => $clients,
        ]);
    }

    /**
     * Display the client create page.
     */
    public function create(): Response
    {
        return Inertia::render('Client/Create');
    }

    /**
     * Display the client edit page.
     */
    public function edit(Request $request): Response
    {
        $client = Client::find($request->id);

        return Inertia::render('Client/Edit', [
            'client' =>  $client,
        ]);
    }

   
    /**
     * Display the client create page.
     */
    public function getdata()
    {
        $clients = Client::all();
        return response()->json($clients);

    }

    /**
     * Store the client
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'name'  => 'required|string|max:255',
            'email' => 'required|string|lowercase|email|max:255|unique:'.Client::class,
            'phone' => 'required|regex:/^\(\d{3}\)\s\d{3}\s-\s\d{4}$/',
            'address' => 'required|string|max:255',
        ],[
            'email.unique' => 'The email address is already registered.',
        ]);

        $user = Client::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'created_by' => 'admin',
        ]);

        
        return Redirect::route('client.index')->with(['type' => 'success', 'message' => 'Client added successfully.']);
        

    }

    /**
     * Update the client
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request, $id): RedirectResponse
    {
        $client = Client::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => [
                'required',
                'string',
                'lowercase',
                'email',
                'max:255',
                Rule::unique(Client::class)->ignore($client->id),
            ],
            'phone' => 'required|regex:/^\(\d{3}\)\s\d{3}\s-\s\d{4}$/',
            'address' => 'required|string|max:255',
        ]);

        //Update details
        $client->name = $request->name;
        $client->email = $request->email;
        $client->phone = $request->phone;
        $client->address = $request->address;
        $client->save();

        return Redirect::route('client.index')->with(['type' => 'success', 'message' => 'Client Updated successfully.']);
    }

    
    /**
     * Delete the specified client.
     * @param  int  $id
     */
    public function delete($id)
    {
        $client = Client::findOrFail($id);

        try {
            $client->delete();
            return true;
        } catch (\Exception $e) {
            return false;
        }  
    }    
}
