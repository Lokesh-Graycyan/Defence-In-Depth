<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User2FaVerification extends Model
{
    use HasFactory;
    protected $table = 'user_2fa_verifications';

    protected $fillable = [
        'user_id',
        'user_secret_codes',
        'twofA_verified',
        'verified_on',
        'interval'
    ];
}
