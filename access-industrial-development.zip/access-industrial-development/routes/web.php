<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\ProposalController;
use App\Http\Controllers\TwoFactorAuthController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Auth/Login', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

//2FA
Route::get('/2fa', [TwoFactorAuthController::class, 'index'])->name('2fa.index');
Route::post('/2fa/verify', [TwoFactorAuthController::class, 'verify'])->name('2fa.verify');

Route::middleware('auth')->group(function () {

    //profile roue
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::post('/profile/remove', [ProfileController::class, 'removeProfilePicture'])->name('profile_picture.remove');
    Route::get('account/verify/{token}', [ProfileController::class, 'verifyAccount'])->name('user.verify'); 

    //client route
    Route::get('client/index', [ClientController::class, 'index'])->name('client.index');
    Route::get('client/create', [ClientController::class, 'create'])->name('client.create');
    Route::post('client/store', [ClientController::class, 'store'])->name('client.store');
    Route::get('client/edit/{id}', [ClientController::class, 'edit'])->name('client.edit');
    Route::post('client/update/{id}', [ClientController::class, 'update'])->name('client.update');
    Route::delete('client/delete/{id}', [ClientController::class, 'delete'])->name('client.delete');
    Route::get('client/data', [ClientController::class, 'getdata'])->name('client.data');

    //proposal route
    Route::get('proposal/index', [ProposalController::class, 'index'])->name('proposal.index');
    Route::get('proposal/create', [ProposalController::class, 'create'])->name('proposal.create');
    Route::post('proposal/store', [ProposalController::class, 'store'])->name('proposal.store');
    Route::get('proposal/edit/{id}', [ProposalController::class, 'edit'])->name('proposal.edit');
    Route::post('proposal/update/{id}', [ProposalController::class, 'update'])->name('proposal.update');
    Route::delete('proposal/delete/{id}', [ProposalController::class, 'delete'])->name('proposal.delete');
    Route::get('proposal/data', [ProposalController::class, 'getdata'])->name('proposal.data');
    
});

require __DIR__.'/auth.php';
