//function to capitalize the first letter of a string
export const capitalize = (string) => {
    if (typeof string !== 'string') {
      return string;
    }
    return string.replace(/\b\w/g, (char) => char.toUpperCase());
  };
