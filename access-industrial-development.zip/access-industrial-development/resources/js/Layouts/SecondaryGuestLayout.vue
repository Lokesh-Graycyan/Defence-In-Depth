<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <div class="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div class="sm:mx-auto sm:w-full sm:max-w-sm">
            <div class="flex justify-center items-center">
                <img class="h-30 w-auto" :src="'assets/images/logos/access-industrial-logo.webp'" alt="Access Industrial Portal" />
            </div>
            <div class="card mt-4">
                <slot />
            </div>

        </div>
    </div>
</template>
