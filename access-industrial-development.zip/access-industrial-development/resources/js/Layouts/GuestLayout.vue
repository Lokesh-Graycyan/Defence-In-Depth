<script setup>

// Define the paths to your images
const logoPath = '/assets/images/logos/access-industrial-logo.webp';
const backgroundImagePath = '/assets/images/yachts/image.png';
</script>

<template>
        <div class="flex h-screen flex-1">
        <div class="flex flex-1 flex-col justify-center px-4 py-10 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
            <div class="mx-auto w-full max-w-sm lg:w-96">
                <div class="flex justify-center items-center">
                    <img class="h-30 w-auto" :src="logoPath"  alt="Access Industrial Portal" />
                </div>
                <div class="mt-4">
                    <slot />
                </div>
            </div>
        </div>
        <div class="relative hidden w-0 flex-1 lg:block">
            <img class="absolute inset-0 h-full w-full"
            :src="backgroundImagePath"
                alt="" />
        </div>
    </div>
</template>
