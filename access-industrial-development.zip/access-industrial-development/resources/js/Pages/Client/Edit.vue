<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { ref } from 'vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, useForm } from '@inertiajs/vue3';
import Spin from '@/Components/Spin.vue';

const props = defineProps({
    client: Object,
})
const form = useForm({
    name: props.client.name,
    email: props.client.email,
    phone: props.client.phone,
    address: props.client.address,
});

const isSpinner = ref(false)
const submit = () => {
    isSpinner.value = true;
    form.post(route('client.update', props.client.id), {
        onFinish: () => {
            isSpinner.value = false;
        },
    });
};
</script>

<template>
    <Head title="Edit Client" />

    <AuthenticatedLayout>
        <div class="w-full md:w-2/6 mt-2">
            <header>
                <h2 class="text-xl font-bold text-gray-900">Edit Client</h2>
                <p class="mt-1 text-sm text-gray-600">
                    Review and update client information as needed.
                </p>
            </header>
        </div>
        <div class="flex flex-col md:flex-row gap-10 mt-5 mb-5 max-w-full border-b border-gray-200 bg-white px-4 py-5 sm:px-6 rounded-md">
            
            <div class="w-full md:w-4/6 pt-4">
                
                <form @submit.prevent="submit">
                    <div>
                        <InputLabel for="name" value="Name" />

                        <TextInput
                            id="name"
                            type="text"
                            class="mt-1 block w-full"
                            v-model="form.name"
                            required
                            autofocus
                            autocomplete="name"
                        />

                        <InputError class="mt-2" :message="form.errors.name" />
                    </div>

                    <div class="mt-4">
                        <InputLabel for="email" value="Email" />

                        <TextInput
                            id="email"
                            type="email"
                            class="mt-1 block w-full"
                            v-model="form.email"
                            required
                            autocomplete="username"
                        />

                        <InputError class="mt-2" :message="form.errors.email" />
                    </div>

                    <div class="mt-4">
                        <InputLabel for="phone" value="Phone" />

                        <TextInput
                            id="phone"
                            type="text"
                            class="mt-1 block w-full"
                            v-model="form.phone"
                            required
                            autofocus
                            autocomplete="phone"
                        />

                        <InputError class="mt-2" :message="form.errors.phone" />
                    </div>

                    <div class="mt-4">
                        <InputLabel for="address" value="Address" />

                        <TextInput
                            id="address"
                            type="text"
                            class="mt-1 block w-full"
                            v-model="form.address"
                            required
                            autofocus
                            autocomplete="address"
                        />

                        <InputError class="mt-2" :message="form.errors.address" />
                    </div>

                    <div class="flex items-center justify-left mt-4">
                        <DefaultButton :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                            Update Client <Spin v-if="isSpinner"/>
                        </DefaultButton>
                    </div>
                </form>
            </div>
        </div>
    </AuthenticatedLayout>
</template>
