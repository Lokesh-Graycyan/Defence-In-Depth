<script setup>
import { ref } from 'vue';
import axios from 'axios';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';
import UserList from '@/Components/UserList.vue';
import SortableTable from "@/Components/SortableTable.vue";
import Pagination from "@/Components/Pagination.vue";
import { TrashIcon, PencilSquareIcon } from '@heroicons/vue/24/outline';
import IconNavigation from '@/Components/IconNavigation.vue';
import IconNavigationButton from '@/Components/IconNavigationButton.vue';
import Dialog from '@/Components/Dialog.vue';
import SuccessDialog from '@/Components/SuccessDialog.vue';

const props = defineProps({
    clients: Object,
});

const tableColumns = ref([
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Phone' },
    { key: 'address', label: 'Address' },
    { key: 'action', label: 'Action' }
]);

//Delete User.
const alert = ref(false)
const success = ref(false)
const actionValue = ref();

const deleteUserConfirmation = (id) => {
    alert.value = true;
    actionValue.value = id;
}

const deleteUser = async ({alertValue, action, actionValue}) => {
    alert.value = alertValue;
    if(action){
        try {
        const response = await axios.delete(`/client/delete/${actionValue}`);
        console.log(response);
        if(response){
           success.value = true;

        }

        } catch (error) {
            console.error('Error deleting client:', error);
        }
    }
};




</script>

<template>
    <Head title="Clients" />

    <AuthenticatedLayout>
        <div class="border-b border-gray-200 bg-white px-4 py-5 sm:px-6 rounded-md">
            <div class="-ml-4 -mt-2 flex flex-wrap items-center justify-between sm:flex-nowrap">
                <div class="ml-4 mt-2">
                    <h3 class="text-xl font-semibold leading-6 text-gray-900">Clients</h3>
                </div>
                <div class="ml-4 mt-2 flex-shrink-0">
                    <NavigateButton :href="route('client.create')"> Add Client</NavigateButton>
                </div>
            </div>
            <SortableTable :columns="tableColumns" :data="clients.data">
                <template v-for="column in tableColumns" v-slot:[column.key]="{ item }">
                    <div v-if="column.key === 'name'">
                        <strong class="mr-2">{{ item.name ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'email'">
                        <strong class="mr-2">{{ item.email ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'phone'">
                        <strong class="mr-2">{{ item.phone ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'address'">
                        <strong class="mr-2">{{ item.address ?? '--' }}</strong>
                    </div>
                    <div v-if="column.key === 'action'" class="items-center">
                        <IconNavigation :href="route('client.edit', item.id)"><component :is="PencilSquareIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigation>
                        <IconNavigationButton  @click="deleteUserConfirmation(item.id)" ><component :is="TrashIcon" class="h-5 w-5" aria-hidden="true" /></IconNavigationButton>
                    </div>
                </template>
            </SortableTable>
            <div class="border-t border-gray-200 pt-5 "></div>
            <div class="pagination-cont">
                <!-- <Pagination :paginationMeta="clients.meta" v-if="props.clients.meta.total > 5" /> -->
            </div>
        </div>

        <Dialog v-if="alert" :actionValue="actionValue" :buttonName="'Delete'" @newData=deleteUser :message="'Are you sure you want to delete this user?'"></Dialog>
        <SuccessDialog v-if="success" :message="'Client Deleted Successfully'"></SuccessDialog>
    </AuthenticatedLayout>
</template>
