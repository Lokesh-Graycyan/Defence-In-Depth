<script setup>
import SecondaryGuestLayout from '@/Layouts/SecondaryGuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import DefaultButton from '@/Components/Buttons/DefaultButton.vue';
import NavigateButton from '@/Components/Buttons/NavigateButton.vue';
import TextInput from '@/Components/TextInput.vue';
import {useForm } from '@inertiajs/vue3';

const props = defineProps({
    email: {
        type: String
    },
    verification: {
        type: Object,
    },
});

const form = useForm({
    email: props.email,
    otp: '',
});

const submit = () => {
    form.post(route('2fa.verify'), {

    });
};
</script>

<template>
    <Head title="2FA" />
    <SecondaryGuestLayout>
        <div class="mt-3">
            <div v-if="(props.verification.is_QR_Code)">
                    <h3 class="text-xl mb-3 text-center font-bold">Multi-factor Authentication</h3>
                    <p class="text-center">Please enter the OTP you received on your authenticator app</p>
                </div>
                <div v-else>
                    <h3 class="text-xl mb-3 text-center font-bold">Multi-factor Authentication</h3>
                    <p class="text-center"> Please use an authenticator of your choice.</p>
                </div>

            <form @submit.prevent="submit" class="space-y-6">
                <TextInput type="hidden" v-model="form.email"/>

                <div v-if="(!props.verification.is_QR_Code)">
                    <div class="py-2 text-center">
                        Please note that Two Factor Authentication works best with Microsoft and Google
                        Authenticator.
                    </div>

                    <div class="flex items-center justify-center">
                        <div class="d-flex justify-content-center" v-html="props.verification.QR_Image">
                        </div>
                    </div>

                </div>
                <div>
                    <TextInput id="otp" type="number" class="mt-1 block w-full" v-model="form.otp" required autofocus
                        autocomplete="username" placeholder="Enter OTP" maxlength="6"/>

                    <InputError class="mt-2" :message="form.errors.otp" />
                </div>

                <div class="text-center">
                    
                    <NavigateButton :href="route('login')"> Cancel</NavigateButton>
                    <DefaultButton class="text-center" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                       Verify OTP
                    </DefaultButton>
                </div>
            </form>
        </div>
    </SecondaryGuestLayout>
</template>
<style>
input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
-webkit-appearance: none;
-moz-appearance: none;
appearance: none;
margin: 0;
}
</style>
