<script setup>
import { Link } from '@inertiajs/vue3';
import { computed } from 'vue';

const props = defineProps({
    href: {
        type: String,
        default: '',
    },
    type: {
        type: String,
        default: 'button',
    },
});

const hasHref = computed(() => !!props.href);

const navigateToLink = () => {
  if (hasHref.value) {
    window.location.href = props.href;
  }
};
</script>

<template>
    <button
        :type="props.type"
        class="inline-flex items-center justify-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150 mr-2"
    >
    <Link :href="props.href">
        <slot />

    </Link>
    </button>
</template>

