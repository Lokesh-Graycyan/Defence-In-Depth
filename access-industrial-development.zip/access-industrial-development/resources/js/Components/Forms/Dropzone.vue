<script setup>
import { useDropzone } from "vue3-dropzone";
import { reactive, watch } from 'vue';
import { TrashIcon } from '@heroicons/vue/24/outline';

const { getRootProps, getInputProps, isFileDialogActive, isDragActive, ...rest } = useDropzone({
  onDrop,
});

watch(isDragActive, () => {
});
watch(isFileDialogActive, () => {
})

function onDrop(acceptFiles, rejectReasons) {
   props.state.files = acceptFiles;
}

function handleClickDeleteFile(index) {
    props.state.files.splice(index, 1);
}
const props = defineProps(['state', 'multiple']);
</script>

<template>
    <div class="w-full h-44 ">
        <div v-if="props.state.files.length > 0" class="files h-56">
            <div class="file-item" v-for="(file, index) in props.state.files" :key="index">
                <span>{{ file.name }}</span>
                <span class="delete-file" @click="handleClickDeleteFile(index)"> <component :is="TrashIcon" class="h-6 w-6" aria-hidden="true" /></span>
            </div>
        </div>
        <div v-else class="cursor-pointer dropzone text-center rounded-md " style="border: 2px dashed #ccc;" v-bind="getRootProps()">
            <div class="box h-44 bg-gray-100" :class="{ 'border-blue-500': isDragActive }">
                <input v-bind="getInputProps()" />
                <p v-if="isDragActive" class="cursor-pointer">Drop the files here ...</p>
                <p v-else class="p-5" >Drag and drop files here, or Click to select files</p>
            </div>

        </div>
    </div>
</template>

<style>
.box {
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.file-item {
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
    background: rgb(59 130 246 / 9%);
  padding: 7px;
  padding-left: 15px;
  margin-top: 10px;
}

  .delete-file {
    background: #f67071;
    color: #fff;
    padding: 5px 10px;
    border-radius: 8px;
    cursor: pointer;

}
</style>
