<template>
    <TransitionRoot :show="show">
        <TransitionChild
            enter="ease-out duration-300"
            enter-from="opacity-0"
            enter-to="opacity-100"
            leave="ease-in duration-200"
            leave-from="opacity-100"
            leave-to="opacity-0"
        >
        </TransitionChild>
        <div
            aria-live="assertive"
            class="pointer-events-none fixed inset-0 flex items-end px-4 py-6 sm:items-start sm:p-6 z-40"
        >
            <div
                class="flex w-full flex-col items-center space-y-4 sm:items-end"
            >

                <div :class="bgColor(type)"
                    class="pointer-events-auto w-full max-w-sm overflow-hidden rounded-lg dark:bg-gray-800 shadow-lg ring-1 ring-black ring-opacity-5"
                >
                    <TransitionRoot
                        enter-active-class="transform ease-out duration-300 transition"
                        enter-from-class="translate-y-2 opacity-0 sm:translate-y-0 sm:translate-x-2"
                        enter-to-class="translate-y-0 opacity-100 sm:translate-x-0"
                        leave-active-class="transition ease-in duration-500"
                        leave-from-class="opacity-100"
                        leave-to-class="opacity-0"
                    >
                        <div class="p-4">
                            <div class="flex items-start">
                                <div class="flex-shrink-0">
                                    <CheckCircleIcon
                                        v-if="type === 'success'"
                                        class="h-6 w-6 text-green-700"
                                        aria-hidden="true"
                                    />
                                    <XCircleIcon
                                        v-if="type === 'error'"
                                        class="h-6 w-6 text-red-800"
                                        aria-hidden="true"
                                    />
                                </div>
                                <div class="ml-3 w-0 flex-1 pt-0.5">
                                    <h3 :class="textColor(type)" class="text-sm font-medium">{{ message }}
                                    </h3>
                                </div>
                                <div class="ml-4 flex-shrink-0">
                                    <button
                                        type="button"
                                        @click="show = false"
                                        class="rounded-md bg-white text-gray-400 hover:text-gray-500 dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                    >
                                        <span class="sr-only">Close</span>
                                        <XMarkIcon
                                            class="h-5 w-5 text-green-700"
                                            aria-hidden="true"
                                        />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </TransitionRoot>
                </div>
            </div>
        </div>
    </TransitionRoot>
</template>

<script setup>
import { computed, onMounted, ref, watch } from "vue";
import { TransitionRoot, TransitionChild } from "@headlessui/vue";
import { CheckCircleIcon, XCircleIcon } from "@heroicons/vue/24/outline";
import { XMarkIcon } from "@heroicons/vue/20/solid";
import { usePage } from "@inertiajs/vue3";

const page = usePage();

const props = defineProps({
    message: {
        required: true,
    },
    type: {
        default: "success", // or 'error'
    },
});
const show = ref(true);
const tempMessage = computed(
    () => page.props?.flash?.message + new Date().toISOString()
);

const triggerTimeout = () => {
    setTimeout(() => {
        show.value = false;
    }, 6000);
};

watch(tempMessage, () => {
    if (!show.value) {
        show.value = true;
    }
    triggerTimeout();
});
const textColor = (type) => {
    if(type === 'success'){
        return `text-green-700`
    }else{
        return `text-red-800`
    }
}
const bgColor = (type) => {
    if(type === 'success'){
        return `bg-green-50 text-green-700`
    }else{
        return `bg-red-400`
    }
}
</script>

