<template>
    <div class="pt-8">
      <DataTable
        :columns="columns"
        :data="data"
        class="display"
        width="100%"
      >
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
        </thead>
      </DataTable>
    </div>
  </template>

  <script setup>
  import DataTable from 'datatables.net-vue3';
  import DataTablesCore from 'datatables.net';
  import { onMounted } from 'vue';
  import { ref } from 'vue';

  DataTable.use(DataTablesCore);

  const columns = [
    { data: 'name' },
    { data: 'email' },
    { data: 'phone' },
    { data: 'address' },
    {
      data: null,
      render: function (data, type, row) {
        return `
          <span class="default-button" click="editUser(${data.id})">Edit</span>
          <span class="danger-button" click="deleteUser(${data.id})">Delete</span>
        `;
      }
    },
  ];

  const data = ref([]);

//   const dataTableOptions = ref({
//     responsive: true // Enable responsiveness
//   });

  onMounted(async () => {
    try {
      const response = await fetch('client/data');
      if (response.ok) {
        const jsonData = await response.json();
        data.value = jsonData;
      } else {
        console.error('Failed to fetch data');
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  });
  </script>

<style>
@import 'datatables.net-dt';

select {
    background-position: right -4.5px center !important;
}
</style>
