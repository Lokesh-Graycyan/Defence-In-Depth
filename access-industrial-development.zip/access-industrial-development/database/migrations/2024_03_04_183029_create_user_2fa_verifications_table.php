<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_2fa_verifications', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id')->nullable();
            $table->text('user_secret_codes')->nullable();
            $table->text('twofA_verified')->nullable();
            $table->datetime('verified_on')->nullable();
            $table->text('interval')->nullable();
            $table->text('login_mac_address')->nullable();
            $table->text('ip_address')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_2fa_verifications');
    }
};
